# How to Install & Setup

## 1. Build & Download
1. Upload this folder to GitHub.
2. Wait for the Action to complete (Green checkmark).
3. Download the `python-scanner-app` artifact.
4. Extract the `.zip` file on your phone.

## 2. Install APK
1. Tap `app-release.apk`.
2. If prompted, enable **"Install from Unknown Sources"**.
3. Complete installation.

## 3. IMPORTANT: Grant Permissions
**The app will NOT work without this step.**

1. Open Android **Settings**.
2. Go to **Apps** > **Python Scanner**.
3. Tap **Permissions** > **Files/Storage**.
4. Select **"Allow Management of All Files"**.
   *(This allows the scanner to actually see the PojavLauncher folder).*

## 4. Run
1. Open the App.
2. You should see "Status: Ready (Bundled)".
3. Press **Start Scan**.
