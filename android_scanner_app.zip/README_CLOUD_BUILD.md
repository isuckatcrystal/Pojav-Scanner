# Android APK - Cloud Build Instructions (Phone Only)

Since you do not have a PC, we will use **GitHub Actions** to build the APK for free in the cloud.

## Step 1: Get the Files
1. Download the `android_project` folder from this Replit.
   - Or manually copy the contents of `main.py`, `scanner.py`, `requirements.txt`, and the `.github` folder.

## Step 2: Create a GitHub Repository
1. Go to [GitHub.com](https://github.com) (Desktop mode recommended on phone) and sign in.
2. Create a **New Repository** (Public or Private).
3. Name it something like `py-scanner-app`.

## Step 3: Upload Files
1. Upload all files from `android_project` to the **ROOT** of your new repository.
   - `main.py` should be at the very top level, not inside a subfolder.
   - `.github/workflows/build.yml` must be exactly in that path.

   **Correct Repo Structure:**
   ```text
   my-repo/
   ├── .github/
   │   └── workflows/
   │       └── build.yml
   ├── main.py
   ├── scanner.py
   ├── requirements.txt
   └── README.md
   ```

## Step 4: Trigger the Build
1. Once you commit (save) the files, go to the **"Actions"** tab in your GitHub repository.
2. You should see a workflow named "Build Android APK" running (yellow circle).
   - If it didn't start automatically, click "Build Android APK" on the left -> "Run workflow".
3. Wait 3-5 minutes for it to turn Green (Success).

## Step 5: Download APK
1. Click on the successful run (the green checkmark title).
2. Scroll down to the **"Artifacts"** section.
3. Click **"python-scanner-app"**.
4. GitHub will download a `.zip` file. Extract it to find `app-release.apk`.
5. Install it on your phone!
