# Android APK Build Instructions

## 1. Environment Setup (Linux/WSL required)

You cannot build the APK directly inside Replit's standard web environment. You need a Linux machine or WSL (Windows Subsystem for Linux) with Python 3 installed.

Install the Flet packaging tool:

```bash
pip install flet
```

## 2. Bundling Logic

The Flet build tool automatically bundles:
- The Python runtime (Python 3.11+).
- All libraries listed in `requirements.txt`.
- All files in the `android_project` folder (including `scanner.py` and `main.py`).

## 3. Build Command

Navigate to the `android_project` folder and run:

```bash
flet build apk --include-packages flet,requests --permissions android.permission.INTERNET,android.permission.READ_EXTERNAL_STORAGE,android.permission.WRITE_EXTERNAL_STORAGE
```

### Explanation of Flags:
- `--include-packages`: Forces specific libraries to be packaged.
- `--permissions`: Adds lines to the AndroidManifest.xml.

## 4. Storage Permissions Note

Android 11+ enforces "Scoped Storage". 
- `READ_EXTERNAL_STORAGE` allows reading media files.
- `scanner.py` runs within the app's internal private storage by default. 
- If your scanner needs to scan the *entire* phone filesystem, that requires the `MANAGE_EXTERNAL_STORAGE` permission, which Google Play rejects for most apps.
- For a personal tool (sideloaded APK), you can add `android.permission.MANAGE_EXTERNAL_STORAGE` to the command above, but you must also request it explicitly in Python code (not included in this basic UI).

## 5. Installing the APK

1. The output file will be in the `build/apk/` folder.
2. Transfer `app-release.apk` to your phone.
3. Enable "Install from Unknown Sources" and install.
